function Header(){
    return (
    <header>
        <div className="container">
            <nav>
                <ul className="mainMenu">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Contacts</a></li>
                    <li><a href="#">Books</a></li>
                </ul>
            </nav>
        </div>
        
       
    </header>
    )
}
export default Header;