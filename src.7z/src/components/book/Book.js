function Book(props){
    const logo = require('../../data/img/'+props.bookItem.fileName);
    return(
        <div className="book_inner col3">
            <h3 className="tac">{props.bookItem.title}</h3>
            <h5 className="tac">{props.bookItem.author}</h5>
            <div className="bookImg">
            <img src={logo} alt="" />
            </div>
            
            <p>{props.bookItem.desc}</p>
        </div>
    )

}
export default Book;