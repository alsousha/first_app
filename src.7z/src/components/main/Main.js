import Book from '../book/Book';
import Data from '../../data/books.json';
function Main(){

    return (
    <div className="main">
        <div className="container">
            <h2 className='tac mt10'>Our books</h2>

            <div className="books_wrapper d-flex jcsb wrap mt5 mb5">
              
                {Data.map((book) => {
                    return <Book bookItem={book}/>
                })}
                
            </div>
        </div>
    </div>
    )
}
export default Main;